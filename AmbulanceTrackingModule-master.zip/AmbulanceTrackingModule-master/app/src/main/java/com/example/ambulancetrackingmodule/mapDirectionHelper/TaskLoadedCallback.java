package com.example.ambulancetrackingmodule.mapDirectionHelper;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}