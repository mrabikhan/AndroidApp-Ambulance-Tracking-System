package com.example.ambulancetrackingmodule.interfaces;

public interface RequestItemClick {
    void requestItemClick(Double lat, Double longi);
}
